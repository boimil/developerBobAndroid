package com.nepal.developerbob.databasehandling;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends ActionBarActivity {

    EditText Addname, Addphone, Addemail;
    String name, phone, mail;
    ContactDAO contactDAO;
    ContactDTO contactDTO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contactDAO = new ContactDAO(this);
        Addname = (EditText) findViewById(R.id.editText_name);
        Addphone = (EditText) findViewById(R.id.editText_phone);
        Addemail = (EditText) findViewById(R.id.editText_mail);


    }

    public void onAddData(View view) {
        Toast.makeText(this, "data successfully Inserted", Toast.LENGTH_SHORT).show();

        name = Addname.getText().toString();
        phone = Addphone.getText().toString();
        mail = Addemail.getText().toString();

        contactDTO = new ContactDTO(name, phone, mail);
        contactDAO.addContact(contactDTO);
        Toast.makeText(this, "data successfully Inserted", Toast.LENGTH_SHORT).show();

    }

    public void onShowData(View view) {


        Intent intent = new Intent(this, RecycleListActivity.class);
        startActivity(intent);

        Toast.makeText(this, "I am running", Toast.LENGTH_SHORT).show();


    }
}