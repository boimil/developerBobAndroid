package com.nepal.developerbob.databasehandling;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

/**
 * Created by Developer Bob on 28/01/2015.
 */
public class BobAdapter extends RecyclerView.Adapter<BobAdapter.MyViewHolder> {

    ContactDAO contactDAO;

    ArrayList<ContactDTO> contactArrayFromdb ;
    ArrayList<ContactDTO> contacts = new ArrayList<>();
    private LayoutInflater inflater;
    Context context;

    public BobAdapter(Context context) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        contactDAO = new ContactDAO(context);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = inflater.inflate(R.layout.singlerow, viewGroup, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int i) {

        contactArrayFromdb = contactDAO.showContacts();

        for (int j = 0; j < contactArrayFromdb.size(); j++) {

            int id = contactArrayFromdb.get(j).getId();
            String name = contactArrayFromdb.get(j).getName();
            String phone = contactArrayFromdb.get(j).getPhone();
            String email = contactArrayFromdb.get(j).getEmail();

            contacts.add(new ContactDTO(id, name, phone, email));

        }

        ContactDTO temp = contacts.get(i);


        holder.id1.setText(String.valueOf(temp.getId()));
        holder.name1.setText(temp.getName());
        holder.phone1.setText(temp.getPhone());
        holder.email1.setText(temp.getEmail());
    }

    @Override
    public int getItemCount() {
        return 3;
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        EditText id1, name1, phone1, email1;
        Button edit, delete;

        public MyViewHolder(View itemView) {
            super(itemView);
            delete = (Button) itemView.findViewById(R.id.button_delete);
            edit = (Button) itemView.findViewById(R.id.button_edit);
            id1 = (EditText) itemView.findViewById(R.id.editText_id);
            name1 = (EditText) itemView.findViewById(R.id.editText_name1);
            phone1 = (EditText) itemView.findViewById(R.id.editText_phone1);
            email1 = (EditText) itemView.findViewById(R.id.editText_mail1);
        }
    }
}
