package com.nepal.developerbob.databasehandling;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;


public class RecycleListActivity extends ActionBarActivity {

    RecyclerView recyclerView;
    BobAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_list);

        Toast.makeText(this, "I am also running", Toast.LENGTH_SHORT).show();

        recyclerView = (RecyclerView) findViewById(R.id.recycleView);
        adapter = new BobAdapter(this);
        Toast.makeText(this, "I am also running 2", Toast.LENGTH_SHORT).show();
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));






    }

}