package com.nepal.developerbob.databasehandling;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.SQLException;

/**
 * Created by Developer Bob on 26/01/2015.
 */
public class SQLiteDataBaseManager extends SQLiteOpenHelper {


    public static final String DATABASE = "TAG";


    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "ContactManager";
    public static final String TABLE_CONTACTS = "contact";

    public static final String KEY_ID = "id";
    public static final String KEY_NAME = "name";
    public static final String KEY_PH_NO = "phone";
    public static final String KEY_EMAIL = "email";

    private Context context;

    private SQLiteDatabase sqLiteDb;


    public SQLiteDataBaseManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_CONTACTS = "CREATE TABLE " + TABLE_CONTACTS + "( "+ KEY_ID  +  "INTEGER PRIMARY KEY, " + KEY_NAME + "TEXT,"
                + KEY_PH_NO + "TEXT, " + KEY_EMAIL + "TEXT" + ")";
        db.execSQL(CREATE_TABLE_CONTACTS);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i2) {
        sqLiteDb.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        onCreate(db);
    }

    public SQLiteDatabase openDatabaseForRead() throws SQLException{

        Log.i("DATABASE", "open db for read called");

        sqLiteDb = this.getReadableDatabase();

        return sqLiteDb;
    }

   public SQLiteDatabase openDatabaseForWrite() throws SQLException{

       Log.i("DATABASE", "open db for write called");

       sqLiteDb = this.getWritableDatabase();

       return sqLiteDb;
   }


    public void closeDataBaseConnection(){
        if(sqLiteDb.isOpen() && sqLiteDb != null){
            sqLiteDb.close();
        }

    }

}
