package com.nepal.developerbob.databasehandling;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by Developer Bob on 26/01/2015.
 */
public class ContactDAO {

    private SQLiteDataBaseManager dbManager;
    private SQLiteDatabase database;

    public ContactDAO(Context context) {
        dbManager = new SQLiteDataBaseManager(context);
    }

    public ArrayList<ContactDTO> showContacts() {
        ArrayList<ContactDTO> contactList = new ArrayList<ContactDTO>();
        try {
            String selectQuery = "SELECT *FROM " + SQLiteDataBaseManager.TABLE_CONTACTS;
            database = dbManager.openDatabaseForWrite();

            Cursor cursor = database.rawQuery(selectQuery, null);

            if (cursor.moveToFirst()) {
                do {
                    ContactDTO contact = new ContactDTO();
                    contact.setId(Integer.parseInt(cursor.getString(0)));
                    contact.setName(cursor.getString(1));
                    contact.setPhone(cursor.getString(2));
                    contact.setEmail(cursor.getString(3));
                    contactList.add(contact);


                } while (cursor.moveToNext());
            }

            cursor.close();
            return contactList;


        } catch (SQLException e) {
            Log.e("all contact", "" + e);
        } finally {
            dbManager.closeDataBaseConnection();
        }

        return contactList;
    }


    public void addContact(ContactDTO contact) {

        try {
            database = dbManager.openDatabaseForWrite();
            ContentValues values = new ContentValues();

            values.put(dbManager.KEY_NAME, contact.getName());
            values.put(dbManager.KEY_PH_NO, contact.getPhone());
            values.put(dbManager.KEY_EMAIL, contact.getEmail());

            database.insert(SQLiteDataBaseManager.TABLE_CONTACTS, null, values);


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
//            dbManager.closeDataBaseConnection();
        }
    }
}