package com.nepal.developerbob.sqlsql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class ContactDAO {

    MyAdapter helper;
    ContactDTO contactDTO ;
    ArrayList<ContactDTO> getContacts = new ArrayList<>();
    Context context;

    public ContactDAO(Context context) {
        helper = new MyAdapter(context);
        contactDTO = new ContactDTO(context);
        this.context = context;
    }

    public long InsertData(ContactDTO contactDTO) {
        SQLiteDatabase database =  helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(helper.KEY_NAME, contactDTO.getName());
        values.put(helper.KEY_PASSWORD, contactDTO.getPassword());

        long id = database.insert(helper.TABLE_NAME, null, values);
        return id;
    }

   public ArrayList<ContactDTO> getAllData()
   {

       SQLiteDatabase database = helper.getWritableDatabase();
       String[] columns = {helper.UID, helper.KEY_NAME, helper.KEY_PASSWORD };
       Cursor cursor = database.query(helper.TABLE_NAME, columns, null, null, null, null, null);
       StringBuffer sb = new StringBuffer();
       while(cursor.moveToNext()){
           int index0 = cursor.getColumnIndex(helper.UID);
           int index1 = cursor.getColumnIndex(helper.KEY_NAME);
           int index2 = cursor.getColumnIndex(helper.KEY_PASSWORD);
           int id = cursor.getInt(index0);
           String name = cursor.getString(index1);
           String password = cursor.getString(index2);
           getContacts.add(new ContactDTO(id, name, password));
       }
       return getContacts;
   }


    public int onUpdateRow(int id , String newName){


        SQLiteDatabase database = helper.getWritableDatabase();
        ContentValues val = new ContentValues();
        val.put(helper.KEY_NAME, newName);
        String[] whereArgs = {"" +id};

        int count = database.update(helper.TABLE_NAME,val,helper.UID + " =?", whereArgs );
        return count;

    }

}
