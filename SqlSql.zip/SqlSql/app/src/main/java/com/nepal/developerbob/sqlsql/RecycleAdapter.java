package com.nepal.developerbob.sqlsql;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

/**
 * Created by Developer Bob on 31/01/2015.
 */
public class RecycleAdapter extends RecyclerView.Adapter<RecycleAdapter.MyViewHolder> {


    private LayoutInflater inflater;
    ContactDAO contact;
    ArrayList<ContactDTO> getDataFromDB;
    Context context;

    RecycleAdapter(Context context) {
        contact = new ContactDAO(context);
        inflater = LayoutInflater.from(context);
        getDataFromDB = contact.getAllData();
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

        View view = inflater.inflate(R.layout.singlerow, viewGroup, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int i) {

        String val = String.valueOf(getDataFromDB.get(i).getId());
        holder.id.setText(val);
        holder.name.setText(getDataFromDB.get(i).getName());
        holder.pass.setText(getDataFromDB.get(i).getPassword());

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = getDataFromDB.get(i).getId();

                String newName = holder.name.getText().toString();
                Message.message(context, newName);
                int count = contact.onUpdateRow(id, newName);

//                Intent intent = new Intent(context, MainActivity.class);
//                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return getDataFromDB.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        EditText id, name, pass;
        Button edit, delete;

        public MyViewHolder(View view) {
            super(view);

            id = (EditText) view.findViewById(R.id.editText_id);
            name = (EditText) view.findViewById(R.id.editText_name);
            pass = (EditText) view.findViewById(R.id.editText_pass);

            edit = (Button) view.findViewById(R.id.buttonUpdate);
            delete = (Button) view.findViewById(R.id.buttonDelete);
        }
    }
}
