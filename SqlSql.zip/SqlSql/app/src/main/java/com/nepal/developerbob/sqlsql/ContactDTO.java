package com.nepal.developerbob.sqlsql;

import android.content.Context;

/**
 * Created by Developer Bob on 31/01/2015.
 */
public class ContactDTO {
    int id;
    String Name;
    String Password;
    Context context;

    public ContactDTO(Context context){
    this.context = context;
    }

    public ContactDTO(int id, String Name, String Password){
        this.id = id;
        this.Name =Name;
        this.Password = Password;
    }

    public ContactDTO( String Name, String Password){
        this.Name =Name;
        this.Password = Password;
    }


    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
