package com.nepal.developerbob.sqlsql;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyAdapter extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Contacts";
    public static final String TABLE_NAME = "Employee";
    public static final String UID = "_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_PASSWORD = "password";
    public static final int VERSION = 3;
    public static final String CREATE_TABLE = " CREATE TABLE " + TABLE_NAME + "(" + UID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_NAME
            + " VARCHAR(255), " + KEY_PASSWORD + " VARCHAR(255)); ";
    private static final String DROP_TABLE = " DROP TABLE IF EXISTS " + TABLE_NAME;

    Context context;

    public MyAdapter(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CREATE_TABLE);
        Message.message(context, "DatabaseCreated");
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersopn) {
        database.execSQL(DROP_TABLE);
        onCreate(database);
        Message.message(context, "Updated");

    }
}
