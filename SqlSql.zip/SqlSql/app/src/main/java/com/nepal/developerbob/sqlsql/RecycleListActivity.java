package com.nepal.developerbob.sqlsql;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;


public class RecycleListActivity extends ActionBarActivity {
    RecyclerView recycle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_list);
        recycle = (RecyclerView) findViewById(R.id.recyclerView);
        RecycleAdapter adapter = new RecycleAdapter(this);
        recycle.setAdapter(adapter);

        recycle.setLayoutManager( new LinearLayoutManager(this));


    }

}