package com.nepal.developerbob.sqlsql;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends ActionBarActivity {

    EditText name, password, detail;
    ContactDTO contactDTO;
    ContactDAO contactDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contactDAO = new ContactDAO(this);


        name = (EditText) findViewById(R.id.EditText_name);
        password = (EditText) findViewById(R.id.EditText_password);
        detail = (EditText) findViewById(R.id.EditText_getData);
    }

    public void onSave(View view) {

        String name1 = name.getText().toString();
        String password1 = password.getText().toString();
        contactDTO = new ContactDTO(name1, password1);

        long id = contactDAO.InsertData(contactDTO);

        if(id < 0){
            Message.message(this, "Data not inserted");
        }else{
            Message.message(this, "Data inserted with much success");
        }

    }

    public void onView(View view) {

        Intent intent = new Intent(this, RecycleListActivity.class);
        startActivity(intent);

    }


}