package com.nepal.developerbob.sqlsql;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by Developer Bob on 31/01/2015.
 */
public class Message {
    public static void message(Context context, String Message){
        Toast.makeText(context, Message, Toast.LENGTH_SHORT).show();
    }
}
